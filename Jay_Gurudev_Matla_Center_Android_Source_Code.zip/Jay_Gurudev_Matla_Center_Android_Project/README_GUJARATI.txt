જય ગુરુદેવ માટલા સેન્ટર — Android APK માટેનો પ્રોજેક્ટ

મહત્વપૂર્ણ:
• આ Android Studio project source છે; આ ZIP પોતે APK નથી.
• HTML ફાઇલ હાલની Vehicle_From_To_Purchase_Fare આવૃત્તિમાંથી ઉમેરેલી છે.
• એપ offline ચાલે તે માટે WebView વપરાય છે.
• HTML એપ localStorage વાપરે છે. APKની WebView storage અને જૂના browser/HTML storage અલગ હોઈ શકે છે; જૂનો ડેટા આપમેળે આયાત થશે એવું માનશો નહીં.
• તમે કહ્યું હતું કે હાલનો ડેટા માત્ર ટેસ્ટ માટે હતો અને જરૂરી નથી, તેથી ખાલી નવી શરૂઆત માટે આ પ્રોજેક્ટ ઉપયોગી છે.
• વાસ્તવિક હિસાબ દાખલ કરતા પહેલાં APK ઇન્સ્ટોલ કરીને ખરીદી/વેચાણ/સ્ટોક/બિલ/બેકઅપ જાતે ચકાસો.

APK બનાવવા:
1. કમ્પ્યુટરમાં Android Studio (તાજેતરનું stable) ઇન્સ્ટોલ કરો.
2. Android Studioમાં Open પસંદ કરી આ ZIP extract કરેલું Jay_Gurudev_Matla_Center_Android_Project ફોલ્ડર ખોલો.
3. Gradle sync પૂરો થવા દો; SDK Platform 35 માંગે તો SDK Managerમાંથી ઇન્સ્ટોલ કરો.
4. Build > Build APK(s) પસંદ કરો.
5. APK સામાન્ય રીતે app/build/outputs/apk/debug/app-debug.apk માં મળશે.

સુરક્ષા નોંધ:
• આ પ્રોજેક્ટમાં cloud sync નથી. ફોન ગુમાય અથવા app data clear/uninstall થાય તો data ગુમાવાનો જોખમ છે.
• એપમાં ઉપલબ્ધ backup/export સુવિધા નિયમિત વાપરો અને બેકઅપ ફોનથી અલગ જગ્યાએ રાખો.
• Android Auto Backup ચાલુ છે, પણ તેને એકમાત્ર બેકઅપ ન માનો.

માત્ર મોબાઇલથી build કરવું હોય તો MOBILE_BUILD_GUIDE_GUJARATI.txt જુઓ. .github/workflows/build-apk.yml GitHub Actions દ્વારા APK build કરવાનો પ્રયાસ કરે છે. આ APK હજી build/test કરેલી નથી.
